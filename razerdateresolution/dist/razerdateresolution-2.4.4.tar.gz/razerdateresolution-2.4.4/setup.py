from distutils.core import setup

setup(
	name				= 'razerdateresolution',
	version				= '2.4.4',
	py_modules			= ['razerdateresolution'],
	author				= 'AlexWang',
	author_email		= 'qinexpire@gmail.com',
	url					= 'https://blog.csdn.net/andrew_wf',
	description			= 'Parsing the date'
)